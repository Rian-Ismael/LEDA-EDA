package forma;

public interface Forma {
	public double area();
}
