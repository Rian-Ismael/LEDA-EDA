package main;

import Questões.ElevaNumero;
import Questões.SomaDoisElementosInteirosPositivos;
import Questões.SomaElementosDeUmArray;
import Questões.VerificaArrayContemN;
import Questões.AlgoritmobuscaBinaria;

public class Main {
	public static void main(String[] args) {
		//Soma somente dois elementos//
		//int[] array = {2, 3, 1, 2};
		//System.out.println(SomaDoisElementosInteirosPositivos.somaDoisElementos(array));
		
		//Eleva ao numero "a"//
		//int valor = ElevaNumero.pot(2, 2);
		//System.out.println(valor);
		
		//Contem N//
		//int[] array = {1, 5, 6, 8, 12, 4};
		//System.out.println(VerificaArrayContemN.contemN(array, 12));
		
		//Soma elementos do Array//
		//int[] array = {1, 5, 6, 8, 12, 4}; // = 36
		//System.out.println(SomaElementosDeUmArray.somaElementosArray(array));
		
		//Busca binaria//
		//int[] array = {1, 4, 5, 6, 8, 12};
		//System.out.println(AlgoritmobuscaBinaria.buscaBinaria(array, 0, array.length, 3));
	}
}
