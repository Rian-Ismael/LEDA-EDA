package vetor;

import solucao.vetor.Vetor;

public class TestarVetor {

	public static void main(String[] args) {
		// preencha esse metodo com codigo para testar a classe vetor.
		// À medida que voce evoluir no exercício o conteúdo deste mpetodo
		// também será modificado.
		Vetor<Aluno> vetor = new Vetor<Aluno>(20);
	}
}
