package teste2;

public interface interfaceClass<T> {
	public abstract void m(T o);
}
