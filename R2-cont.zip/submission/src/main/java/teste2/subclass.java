package teste2;

public  class subclass<T> implements interfaceClass<T> {


	@Override
	public void m(T o) {
		// TODO Auto-generated method stub
		
	}
}
