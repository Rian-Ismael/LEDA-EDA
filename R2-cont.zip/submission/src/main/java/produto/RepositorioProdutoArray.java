package produto;

public class RepositorioProdutoArray<T extends Produto> implements InterfaceProduto<T> { 

	private T[] produtos;
	 
	int index = -1;
	
	public  RepositorioProdutoArray(int size) {
		this.produtos = (T[]) new Object[size]; 
	}
 
	/**
	 * Recebe o codigo do produto e devolve o indice desse produto no array ou
	 * -1 caso ele nao se encontre no array. Esse método é util apenas na
	 * implementacao com arrays por questoes de localizacao. Outras classes que
	 * utilizam outras estruturas internas podem nao precisar desse método.
	 * 
	 * @param codigo
	 * @return
	 */
	private int procurarIndice(int codigo) {
		for(int i = 0; i < produtos.length; i++) {
			if(produtos.equals(produtos[i])) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Recebe o codigo e diz se tem produto com esse codigo armazenado
	 * 
	 * @param codigo
	 * @return
	 */
	public boolean existe(int codigo) {
		for(int i = 0; i < produtos.length; i++) {
			if(produtos.equals(produtos[i])) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Insere um novo produto (sem se preocupar com duplicatas)
	 */
	public void inserir(T produto) {
		produtos[index++] = produto;

	}

	/**
	 * Atualiza um produto armazenado ou retorna um erro caso o produto nao
	 * esteja no array. Note que, para localizacao, o código do produto será
	 * utilizado.
	 */
	public void atualizar(T produto) {
		int indice = procurarIndice(produto.getCodigo());
		if(index != -1) {
			produtos[indice] = produto;
			
		} else {
		throw new UnsupportedOperationException("Produto nao encontrado");
		}
	}

	/**
	 * Remove produto com determinado codigo, se existir, ou entao retorna um
	 * erro, caso contrário. Note que a remoção NÃO pode deixar "buracos" no
	 * array.
	 * 
	 * @param codigo
	 */
	public void remover(int codigo) {
		int indice = procurarIndice(codigo);
		if(indice != -1) {
			produtos[indice] = produtos[index];
			produtos[index] = null;
			index--;

		} else {
		throw new UnsupportedOperationException("Produto nao encontrado");
		}
	}

	/**
	 * Retorna um produto com determinado codigo ou entao um erro, caso o
	 * produto nao esteja armazenado
	 * 
	 * @param codigo
	 * @return
	 */
	public Produto procurar(int codigo) {
		if(existe(codigo)) {
			int indice = procurarIndice(codigo);
			return produtos[indice];
		} else {
		throw new UnsupportedOperationException("Produto nao encontrado");
		}
	}

	
}
