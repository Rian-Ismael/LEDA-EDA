package produto;

public interface InterfaceRepositorioProduto {

	public abstract void inserir(int codigo);
	
	public abstract void remover(int codigo);
	
	public abstract void procurarIndice(int codigo);
	
	public abstract void existe(int codigo);
	
	public abstract void atualizar(Produto produto);
	
	public abstract void procurar(int codigo);
}
