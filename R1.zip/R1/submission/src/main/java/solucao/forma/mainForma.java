package solucao.forma;

public class mainForma {
	public static void main(String[] args) {
		Forma retangulo = new Retangulo(1.5, 1.5);
		Forma quadrado = new Quadrado(2);
		Forma circulo = new Circulo(3);
		Forma triangulo = new Triangulo(2, 3);
		
		
		System.out.println(retangulo.area());
		System.out.println(quadrado.area());
		System.out.println(circulo.area());
		System.out.println(triangulo.area());
		
	}
}
