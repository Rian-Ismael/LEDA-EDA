package teste;

public class MinhaListaInteger extends MinhaListaImpl<Integer>{

}
