package teste;

import java.util.ArrayList;

public class MinhaListaImpl<T> implements MinhaLista<T> {
	private ArrayList<T> listaInterna = new ArrayList<T>();


	public void add(T o) {
		listaInterna.add(o);
	}


	public void remove(T o) {
		listaInterna.remove(o);
	}
}