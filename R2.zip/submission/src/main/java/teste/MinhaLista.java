package teste;

public interface MinhaLista<T> {
	
	public abstract void add(T o);
	public abstract void remove(T o);
}
