package teste;

public class main {

	public static void main(String[] args) {
		MinhaListaImpl<Integer> listaInteiros = new MinhaListaImpl<Integer>();
		MinhaListaImpl<String> listaString = new MinhaListaImpl<String>();
	}
}
