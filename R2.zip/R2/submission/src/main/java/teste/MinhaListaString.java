package teste;

public class MinhaListaString extends MinhaListaImpl<String> {

}
