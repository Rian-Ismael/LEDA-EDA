package recursao;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
		
		MetodosRecursivos metodos = new MetodosRecursivos();
		
		// SOMA ARRAY //
		//int[] array1 = {2, 4, 5, 1}; // = 12
		//int[] array2 = {1, 1, 1, 1, 1, 1}; // = 6
		
		//int somaArray = metodos.calcularSomaArray(array1);
		//System.out.print(somaArray1);
		
		//int somaArray2 = metodos.calcularSomaArray(array2);
		//System.out.print(somaArray2);
		
		//#############################################################//
		
		// FACTORIAL //
		//metodos.calcularFatorial(5);
		//metodos.calcularFatorial(0);
		//metodos.calcularFatorial(1);

		//#############################################################//
		
		//FIBONACCI//
		//int saida1 = metodos.calcularFibonacci(1);
		//int saida2 = metodos.calcularFibonacci(0);
		//int saida4 = metodos.calcularFibonacci(4);
		//System.out.println(saida1);
		//System.out.println(saida0);
		//System.out.println(saida4);
		
		//#############################################################//
		
		//CountNull//
		//Object[] array1 = new Object[20];
		//array1[2] = 1;
		//array1[5] = 2;
		//array1[8] = 3;
		// quantidade de nulos 20 - 3 = 17;
		//int saida1 = metodos.countNotNull(array1);
		//System.out.println(saida1);
		
		//Object[] array2 = new Object[20];
		//int saida2 = metodos.countNotNull(array2);
		//System.out.println(saida2);
		
		//#############################################################//
		
		//Potencia2//
		//long saida1 = metodos.potenciaDe2(0);
		//System.out.println(saida1);
		
		//long saida2 = metodos.potenciaDe2(4);
		//System.out.println(saida2);
		
		//#############################################################//
		
		//PA//
		//2 + (2 + 2 + 2) = 8
		//double saida1 = metodos.progressaoAritmetica(2, 2, 3);
		//System.out.println(saida1);
		//1 + (2 + 2 + 2) = 7
		//double saida2 = metodos.progressaoAritmetica(1, 2, 3);
		//System.out.println(saida2);
		
		//PG//
		//2 * 2 * 2 = 8
		//double saida1 = metodos.progressaoGeometrica(2, 2, 2);
		//System.out.println(saida1);
	}
}
